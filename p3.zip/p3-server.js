// Import the built-in fs package
const fs = require('fs');

// Import the third-party Fastify package
const fastify = require('fastify')();

// Import the coinCount function from the p3-module.js code module file
const { coinCount } = require('./p3-module.js');

// Add a GET route for / that reads and returns index.html
fastify.get('/', (request, reply) => {
  // Read the index.html file contents using the readFile() fs function
  fs.readFile(`${__dirname}/index.html`, (err, data) => {
    if (err) {
      // Return a status code of 500 if there's an error
      reply.code(500).send('Error loading index.html');
    } else {
      // Return the index.html contents with a status code of 200
      reply.code(200).header('Content-Type', 'text/html').send(data);
    }
  });
});

// Add a new GET route, /coin
fastify.get('/coin', (request, reply) => {
  // Extract the denom and count query parameters from request.query using object deconstruction, with default values of 0.
  const { denom = 0, count = 0 } = request.query;
  // Convert the query parameters from strings to integers
  const denomInt = parseInt(denom);
  const countInt = parseInt(count);

  if (denomInt === 0 || countInt === 0) {
    // If either the denom or count is missing or invalid, return a status code of 400 (Bad Request)
    reply.code(400).send('Invalid parameters');
  } else {
    // Otherwise, calculate the appropriate coin calculation using the coinCount() function
    const coinValue = coinCount({ denom: denomInt, count: countInt });

    // Return the result with a status code of 200, and an appropriate Content-Type MIME header
    reply
      .code(200)
      .header('Content-Type', 'text/html')
      .send(
        `<h2>Value of ${countInt} of ${denomInt} is ${coinValue}</h2><br /><a href="/">Home</a>`
      );
  }
});

// Add a new GET route, /coins
fastify.get('/coins', (request, reply) => {
  // Extract the option query parameter from request.query using object deconstruction, with no default value
  const { option } = request.query;

  switch (option) {
    case '1':
      // Calculate the coin value for option 1 using the coinCount() function
      const option1Value = coinCount(
        { denom: 5, count: 3 },
        { denom: 10, count: 2 }
      );
      // Return the result with a status code of 200, and an appropriate Content-Type MIME header
      reply
        .code(200)
        .header('Content-Type', 'text/html')
        .send(
          `<h2>Option ${option} value is ${option1Value}</h2><br /><a href="/">Home</a>`
        );
      break;

    case '2':
      // Calculate the coin value for option 2 using the coinCount() function
      const coins = [
        { denom: 25, count: 2 },
        { denom: 1, count: 7 }
      ];
      const option2Value = coinCount(...coins);
      // Return the result with a status code of 200, and an appropriate Content-Type MIME header
      reply
